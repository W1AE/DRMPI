function X_train_processing(batch_num)

for batch=1:batch_num
    load Training.mat;
    TrainingNO_save=size(X_train,1);                     %training samples number
    
    TrNO=round(TrainingNO_save/batch_num);
    X_train=X_train(TrNO*(batch-1)+1:min(TrNO*batch,TrainingNO_save),:);
    X_train=X_train';
    filename1=['layer_1\X_i\X-TRAIN' num2str(batch) '.mat'];%%%%%%%%%save x-train
    save(filename1, 'X_train', '-v7.3');
end

end