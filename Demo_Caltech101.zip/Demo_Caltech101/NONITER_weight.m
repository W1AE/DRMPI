function [belta, belta_save, K] = NONITER_weight(H_out_map, T_train, belta_save, batch, C, K, ActivationFunction)
TrainingNO=size(H_out_map,2);
HiddenNO=size(H_out_map,1);
switch lower(ActivationFunction)
    case {'sig','sigmoid'}
        P_out=T_train;
        P_in=(-log((1./P_out)-1));
    case {'sin','sine'}
        P_out=T_train;
        P_in=asin(P_out);
    case {'no'}
        P_in=T_train;
end
P_in=real(P_in);
H_out_map=H_out_map';
P_in=P_in';

%% Original
if C == 0%beta=alpha*H';
    K=(eye(size(H_out_map,2))/C+H_out_map'*H_out_map)^(-1);
    belta=K*H_out_map'*P_in;
else 
    K=(eye(size(H_out_map,2))/C+H_out_map'*H_out_map)^(-1);
    belta=K*H_out_map'*P_in;
end
belta=belta';
belta_save=belta;

%% Correntropy
% flag=0;
% iteration=1;
% Jmmcc=zeros(1,iteration);
% %beta=inv(eye(size(H_out_map,2))/C+H_out_map'*H_out_map)^(-1)*H_out_map'*P_in;
% beta=zeros(size(H_out_map,2),1);
% sigma=3;
% K=20;
% epsilon=0.0001;
% 
% while(iteration<K && flag==0)
%     e=P_in-H_out_map*beta;
%     %e1=immse(P_in,H_out_map*beta)';
%     
%     G_matrix=(exp(-1*(e.*e)/2*(sigma*sigma)))/(sigma*sigma);
%     D_matrix=diag(G_matrix);
%     beta=(H_out_map'*D_matrix*H_out_map+2*eye(size(H_out_map,2))/C)^(-1)*H_out_map'*D_matrix*P_in;
%     Jmmcc(1,iteration)=sum(P_in-H_out_map*beta)/size(P_in,1);
%     %Jmmcc(1,iteration)=1-sum(G_matrix)/size(G_matrix,1);
%     if iteration>1 &&Jmmcc(1,iteration)<epsilon
%         flag=1;
%     end
%     iteration=iteration+1;
% end
% belta=beta';
% belta_save=beta';



%belta(abs(belta)<0.001)=0;

clear H_out_map;
clear error_in;
clear b1;
clear b2;
clear T_train;
end