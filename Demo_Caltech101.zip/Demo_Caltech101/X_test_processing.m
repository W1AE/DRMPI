function X_test_processing()

load Testing;

X_test=X_test';
filename1=['layer_' num2str(1) '\tes\' 'X-TEST' '.mat'];
save(filename1, 'X_test', '-v7.3');

end