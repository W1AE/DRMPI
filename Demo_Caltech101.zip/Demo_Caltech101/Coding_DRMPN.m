%%% This file is to reproduce the results of Table IV
%%% DRMPN on Caltech101 dataset using ResNet-50 feature: Accuracy=91.9

clear all;
Hidden=1000;   %The number of neurons in each FRB

%% [1] Reproduce the result in Table IV

C1 = 2;
ACCA_b=My_Demo(C1, Hidden, 300, 1);
ACCA_b