function [TestingAccuracy]=classification_te(InputWeight, ActivationFunction, number_of_AEs, channel, subnetwork, sub)
relu=2;% if equal to 1, do the process.
layer=1;

for i=1:number_of_AEs+1
    InputWeight1=InputWeight{i}';
    if i < number_of_AEs+1
        layer=initial_layer(InputWeight1',layer,relu,ActivationFunction,0);%1st
    end
    if i == number_of_AEs && subnetwork == sub
         Obtain_test(layer, channel);%?if??
    end
    if i == number_of_AEs+1
        forward_lastlayer(0, ActivationFunction, InputWeight1', layer);%?
    end
end

filename1=['layer_1\H_f\' 'H_test-feature' num2str(number_of_AEs+1) '.mat'];
load(filename1);
filename3=['layer_1\tes\T-TEST' '.mat'];
load(filename3);

MissClassificationRate_Test=0;
for j = 1 : size(T_test, 2)
    [x, label_index_expected]=max(T_test(:,j));
    [x, label_index_actual]=max(Y_out(:,j));
    if label_index_actual~=label_index_expected
        MissClassificationRate_Test=MissClassificationRate_Test+1;
    end
end

TestingAccuracy = 1-MissClassificationRate_Test/size(Y_out,2);

end