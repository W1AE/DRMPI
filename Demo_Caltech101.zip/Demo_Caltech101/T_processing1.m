function T_processing1(batch_num,numClasses)

load T_train.mat;
load T_test.mat;

sorted_target=sort(cat(2,T_train',T_test'),2);
TrainingNO_save=size(T_train,1);
TestingNO=size(T_test,1);

label=zeros(1,1);                               %Find and save in 'label' class label from training and testing data sets
label(1,1)=sorted_target(1,1);
j=1;
for i = 2:size(sorted_target,2)
    if sorted_target(1,i) ~= label(1,j)
        j=j+1;
        label(1,j) = sorted_target(1,i);
    end
end
OutputNO=numClasses;

min_v=1000;
number_of_class=j;
D = zeros(length(T_train),length(T_train));
number_of_each_class_of_train_data = zeros(length(label),1);
for k = 1:length(label)
    
    [~,position] = find(T_train == label(k));
    number_of_each_class_of_train_data(k) = length(position);
    
    for kk=1:length(T_train) 
        if T_train(kk) == label(k)
            D(kk,kk) = number_of_class/(number_of_class * number_of_each_class_of_train_data(k));
            if D(kk,kk)<min_v
                min_v=D(kk,kk);
            end
        end
    end
    clear position
end
%D=D*1/min_v;

% for ij=1:size(D,1)
%     aa(ij)=D(ij,ij);
% end
% aa_o=mapminmax(aa,0.1,2);
% for ij=1:size(D,1)
%     D(ij,ij)=aa_o(ij);
% end
save D1.mat D number_of_class -v7.3;
aa=[];
aa_o=[];

%%%%%%%%%% Processing the targets of training
temp_T=zeros(TrainingNO_save, OutputNO);    %get the expect result of the training data.���?T����
for i = 1:TrainingNO_save
    for j = 1:OutputNO
        if label(1,j) == T_train(i,1)
            break;
        end
    end
    temp_T(i,j)=1;
end
%T_train=temp_T;
T_train=(temp_T*2-1);


%%%%%%%%%% Processing the targets of testing
temp_TV_T=zeros(TestingNO, OutputNO);   %get the expect result of the testing data.
for i = 1:TestingNO
    for j = 1:OutputNO
        if label(1,j) == T_test(i,1)
            break;
        end
    end
    temp_TV_T(i,j)=1;
end
%T_test=temp_TV_T;
T_test=(temp_TV_T*2-1);


T_train=T_train';
filename2=['layer_1\X_i\T-TRAIN.mat'];%%%%%%%%%save y-train
save(filename2, 'T_train', '-v7.3');
T_test=T_test';
filename1=['layer_' num2str(1) '\tes\' 'T-TEST' '.mat'];
save(filename1, 'T_test', '-v7.3');


T_train_old=T_train;
for batch=1:batch_num
    TrNO=round(TrainingNO_save/batch_num);
    T_train=T_train_old(:,TrNO*(batch-1)+1:min(TrNO*batch,TrainingNO_save));
    filename2=['layer_' num2str(1) '\X_i\' 'T-TRAIN' num2str(batch) '.mat'];%%%%%%%%%save y-train
    save(filename2, 'T_train', '-v7.3');
end
end