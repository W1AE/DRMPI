function [H_out_map]=FORWARD_feature(X_train, ActivationFunction, IW)%??????X????????H

H_in=IW*X_train;
switch lower(ActivationFunction)
    case {'sig','sigmoid'}
        H_out_map = 1 ./ (1 + exp(-H_in))*2-1;
    case {'sin','sine'}
        H_out_map = sin(H_in);
    case {'no'}
        H_out_map = H_in;
end

end